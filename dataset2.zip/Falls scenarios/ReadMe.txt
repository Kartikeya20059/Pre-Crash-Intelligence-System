The data Format is :
1st Column : Time (s)
2nd Column : Ax(m/s^2)
3rd Column : Ay(m/s^2)
4th Column : Az(m/s^2)
5th Column : Rx(degres(�)/s)
6th Column : Ry(degres(�)/s)
7th Column : Rz(degres(�)/s)

Fall datasets :
1-Fall with leaning of the motorcycle
2-Fall on a slippery straight road section
3-Fall in the roundabout
4-Fall in a curve
