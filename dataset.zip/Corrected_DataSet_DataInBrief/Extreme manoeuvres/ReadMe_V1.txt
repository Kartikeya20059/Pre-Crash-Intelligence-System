The data Format is :
1st Column : Time (s)
2nd Column : Ax(m/s^2)
3rd Column : Ay(m/s^2)
4th Column : Az(m/s^2)
5th Column : Rx(degres(�)/s)
6th Column : Ry(degres(�)/s)
7th Column : Rz(degres(�)/s)

Extreme manoeuvres datasets :
1-Acceleration On Curve
2-Acceleration On Straight Line
3-Fall Like manoeuvres (1, 2, 3)
4-Harsh breaking On Straight Line
